This program, is at its most basic form, a game.

The necessary modules for python are:
-pygame (https://www.pygame.org/wiki/GettingStarted)
-PIL 	(http://www.pythonware.com/products/pil/)

for both of these modules, you will have to download them from their respective websites and then install them to python using pip or a similar method.

Once you have these modules installed and working in python, you can then download this game.

it will include:
- level folder
- game itself
- main help screen
- secondary help screen
- music file

With this all located in the same folder, you can then run the game and it should all run properly


-Kevin-

